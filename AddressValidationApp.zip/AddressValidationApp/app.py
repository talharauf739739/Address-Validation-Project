import pandas as pd
import joblib
import regex as re
from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

# Load the trained XGBoost model
model_filename = 'D:/Talha/Office/Address_API/Deployment/Address_Validation_Updated/AddressValidationApp/models/Address_Validation_Model_Updated.joblib'  # Adjust the path as needed
loaded_model = joblib.load(model_filename)

# Define the replacements for the address column
replacements = {
    r'\bH\b': 'House',
    r'\bh\b': 'house',
    r'\bH(?![oO])\b': 'House',
    r'\bh(?![oO])\b': 'house',
    r'\bst\b': 'Street',
    r'\bSt\b': 'Street',
    r'\bST\b': 'Street',
    r'\bST(?![rR])\b': 'Street',
    r'\bSt(?![rR])\b': 'Street',
    r'\bst(?![rR])\b': 'Street'
}

# Function to perform replacements
def replace_words(text):
    if isinstance(text, str):
        for pattern, replacement in replacements.items():
            text = re.sub(pattern, replacement, text)
        return text
    else:
        return text

# Function to extract feature 2
def extract_feature_2(text):
    return 'True' in text

# Function to check for a specific pattern in the address
def check_pattern(address):
    return (
        re.compile('House|house|HOUSE|H|no|NO|No|number|Number|n|N|Street|St|st|street|STREET').search(address) is not None
        or
        re.compile('House|house|HOUSE|H|no|NO|No|number|Number|n|N|Street|St|st|street|STREET \d').search(address) is not None
    )

# Function to perform API validation
def validate_address(address, province, city):
    # Implement your API validation logic here
    # This function should return 'Y' or 'N' based on your API result
    # You can use the Geoapify API as shown in your original code

    # Example: (You should replace this with your actual API validation logic)
    API_KEY = "00f15a2629b744fe9e2c1088c1d521db"  # Replace with your API key
    url = f"https://api.geoapify.com/v1/geocode/search?text={address}, {city}, {province}&limit=1&apiKey={API_KEY}"

    try:
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            if data.get("features"):
                return "Y"
            else:
                return "N"
        else:
            return "N"
    except requests.exceptions.RequestException:
        return "N"

# Define the API endpoint for prediction
@app.route('/predict', methods=['POST'])
def predict():
    # Get data from the request
    data = request.form  # Assuming form input

    # Extract features from the input data
    address = data['address']
    province = data['province']
    city = data['city']

    # Perform API validation
    API_Output = validate_address(address, province, city)

    # Check for the pattern in the address and set API_Match accordingly
    API_Match = API_Output == "Y" and check_pattern(address)

    # Create a DataFrame with the extracted features
    input_data = pd.DataFrame({
        'API': API_Match,  # True or False
        'Featured_1': [check_pattern(address)],
        'Featured_2': [extract_feature_2(str(API_Match))],
        'Featured_3': [check_pattern(address)]
    })

    # Make predictions using the loaded model
    y_pred_encoded = loaded_model.predict(input_data)

    # Decode the predicted labels
    def decode(y_pred_encoded):
        if y_pred_encoded == 0:
            return 'Complete'
        else:
            return 'Incomplete'

    # Decode the predicted labels
    predicted_labels = decode(y_pred_encoded)

    # Return the predicted label and API_Match as JSON
    result = {"predicted_label": predicted_labels, "API_Match": API_Match}
    return jsonify(result)

# Define a route to render the HTML form
@app.route('/')
def home():
    return render_template('index2.html')

if __name__ == '__main__':
    app.run(port=8080)
